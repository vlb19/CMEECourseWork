#!/bin/bash
#PBS -l walltime=12:00:00
#PBS -l select=1:ncpus=1:mem=5gb
module load anaconda3/personal
echo "R is about to run"
R --vanilla < $HOME/HPC_nuclear.R
mv NuclearRun* $HOME
echo "R has finished running"
